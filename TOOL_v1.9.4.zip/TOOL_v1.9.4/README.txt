﻿SHIN BUDOKAI 2 TRANSFORMATIONS TOOL  v1.9.4
=============================================

[EN] English
1. Run SB2TransformationsTool.exe: it opens in its own window (nothing is installed, nothing goes online).
   If the window cannot open on your PC, the tool opens in your web browser instead.
2. Choose your own ISO of Dragon Ball Z Shin Budokai 2 (Europe ULES00789 / Japan ULJS00107)
   or Shin Budokai - Another Road (USA ULUS10234). The original ISO is never modified.
3. Pick the options (ki per form, going back, extras, loading screen, flash and silhouette colors) and press "Create ISO".
   The tool writes a new copy of the ISO.
Online / ad hoc: compare the "Online code" (section 7) with the other players. Same code = compatible ISOs.
To give your options to a friend: copy the "Settings code" (section 7); they paste it and press "Apply". See ONLINE.txt.
PSP with ARK-4: add "<GAME ID>, highmem, on" to SETTINGS.TXT (the tool shows the exact line). PSP-1000 not supported.
Windows may warn about an unknown publisher (the program is not signed): choose "More info" > "Run anyway".
Translations: to fix a text, copy a file from "lang-edit" into a folder named "lang" next to the program and edit it.
Advanced: "SB2TransformationsTool.exe -browser" opens the interface in the browser, as in older versions.

[JA] 日本語
SB2TransformationsTool.exe を起動すると、専用のウィンドウで開きます（開けない場合はブラウザで開きます）。
元のISOを選び、オプションを設定して「ISOを作成」を押してください。元のISOは変更されません。
オンライン/アドホック: 「オンラインコード」(7番) を他のプレイヤーと比べてください。同じなら互換性があります。設定を渡すには「設定コード」をコピーし、相手が貼り付けて「適用」を押します (ONLINE.txt)。
文章の修正: 「lang-edit」のファイルをプログラムの横の「lang」フォルダにコピーして編集してください。

[ES] Español
Ejecuta SB2TransformationsTool.exe (se abre en su propia ventana; si no puede, en el navegador), elige tu ISO original,
marca las opciones y pulsa "Crear ISO". La ISO original no se modifica.
En línea / ad hoc: comparad el "Código en línea" (sección 7) con los demás jugadores. Mismo código = ISO compatibles. Para pasar tus opciones: copia el "Código de ajustes"; tu amigo lo pega y pulsa "Aplicar" (ONLINE.txt).
Para corregir textos: copia un archivo de "lang-edit" a una carpeta "lang" junto al programa.

[PT] Português (Brasil)
Execute SB2TransformationsTool.exe (abre em uma janela própria; se não for possível, no navegador), escolha a sua ISO original,
marque as opções e clique em "Criar ISO". A ISO original não é alterada.
Online / ad hoc: comparem o "Código online" (seção 7) com os outros jogadores. Mesmo código = ISOs compatíveis. Para passar suas opções: copie o "Código de configurações"; seu amigo cola e clica em "Aplicar" (ONLINE.txt).
Para corrigir textos: copie um arquivo de "lang-edit" para uma pasta "lang" ao lado do programa.

[IT] Italiano
Avvia SB2TransformationsTool.exe (si apre in una sua finestra; se non è possibile, nel browser), scegli la tua ISO originale,
imposta le opzioni e premi "Crea ISO". La ISO originale non viene modificata.
Online / ad hoc: confrontate il "Codice online" (sezione 7) con gli altri giocatori. Stesso codice = ISO compatibili. Per passare le tue opzioni: copia il "Codice impostazioni"; l'amico lo incolla e preme "Applica" (ONLINE.txt).
Per correggere i testi: copia un file da "lang-edit" in una cartella "lang" accanto al programma.

[FR] Français
Lancez SB2TransformationsTool.exe (il s'ouvre dans sa propre fenêtre ; sinon dans le navigateur), choisissez votre ISO d'origine,
réglez les options et cliquez sur « Créer l'ISO ». L'ISO d'origine n'est jamais modifiée.
En ligne / ad hoc : comparez le « Code en ligne » (section 7) avec les autres joueurs. Même code = ISO compatibles. Pour transmettre vos options : copiez le « Code des réglages » ; votre ami le colle et clique sur « Appliquer » (ONLINE.txt).
Pour corriger les textes : copiez un fichier de « lang-edit » dans un dossier « lang » à côté du programme.

[DE] Deutsch
Starte SB2TransformationsTool.exe (öffnet sich in einem eigenen Fenster; falls das nicht geht, im Browser), wähle deine Original-ISO,
stelle die Optionen ein und klicke auf „ISO erstellen“. Die Original-ISO wird nicht verändert.
Online / Ad-hoc: vergleicht den „Online-Code“ (Abschnitt 7) mit den anderen Spielern. Gleicher Code = kompatible ISOs. Optionen weitergeben: den „Einstellungscode“ kopieren; der Freund fügt ihn ein und klickt auf „Übernehmen“ (ONLINE.txt).
Texte korrigieren: eine Datei aus „lang-edit“ in einen Ordner „lang“ neben dem Programm kopieren.

Unofficial fan-made tool. Dragon Ball Z and Shin Budokai are trademarks of their respective owners.
