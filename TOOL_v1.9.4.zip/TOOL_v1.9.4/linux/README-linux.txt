SB2 Transformations Tool v1.9.4 - Linux

[EN] English
SB2TransformationsTool-linux-x64   : 64-bit Linux PC, Steam Deck
SB2TransformationsTool-linux-arm64 : 64-bit ARM (Raspberry Pi 4/5 with a 64-bit system, etc.)
Start:  chmod +x SB2TransformationsTool-linux-x64  &&  ./SB2TransformationsTool-linux-x64
It opens in your default browser.
The "Browse" button uses zenity (GNOME) or kdialog (KDE, Steam Deck); if neither is installed, paste the ISO path in the text field.
Command line:
  ./SB2TransformationsTool-linux-x64 -cli -in game.iso -out new.iso -settings settings.json
  (settings.json = file created with "Save settings"; at the end it prints the online code)
  ./SB2TransformationsTool-linux-x64 -cli -in game.iso
  (read only: version and online code of an ISO already created)

[IT] Italiano
SB2TransformationsTool-linux-x64   : PC Linux 64 bit, Steam Deck
SB2TransformationsTool-linux-arm64 : ARM 64 bit (Raspberry Pi 4/5 con sistema a 64 bit, ecc.)
Avvio:  chmod +x SB2TransformationsTool-linux-x64  &&  ./SB2TransformationsTool-linux-x64
Si apre nel browser predefinito.
Il pulsante "Sfoglia" usa zenity (GNOME) o kdialog (KDE, Steam Deck); se mancano, incolla il percorso dell'ISO nel campo di testo.
Riga di comando: gli stessi comandi qui sopra. settings.json = file creato con "Salva impostazioni";
senza -out il programma mostra solo la versione e il codice online dell'ISO.
